#!/bin/bash

DIR="/root/practice3/part2"
CONF="$DIR/observer.conf"
LOG="$DIR/observer.log"

if [[ ! -f "$CONF" ]]; then
    echo "Ошибка: файл observer.conf не найден"
    exit 1
fi

# Проверяем каждую задачу из конфигурации
while IFS= read -r task || [[ -n "$task" ]]; do

    # Пропускаем пустые строки и комментарии
    [[ -z "$task" || "$task" == \#* ]] && continue

    if [[ ! -x "$task" ]]; then
        echo "$(date '+%F %T') Ошибка: $task недоступен" >> "$LOG"
        continue
    fi

    # Ищем запущенную задачу через /proc
    found=0

    for proc in /proc/[0-9]*; do
        pid="${proc##*/}"

        [[ "$pid" == "$$" ]] && continue
        [[ -r "$proc/cmdline" ]] || continue

        cmdline=$(tr '\0' '\n' < "$proc/cmdline" 2>/dev/null)

        if printf '%s\n' "$cmdline" | grep -Fxq -- "$task"; then
            found=1
            break
        fi
    done

    # Если задача отсутствует, запускаем её
    if (( found == 0 )); then
        (
            cd "$DIR" || exit 1
            nohup "$task" > /dev/null 2>&1 < /dev/null &
        )

        echo "$(date '+%F %T') Запущена задача: $task" >> "$LOG"
    fi

done < "$CONF"
