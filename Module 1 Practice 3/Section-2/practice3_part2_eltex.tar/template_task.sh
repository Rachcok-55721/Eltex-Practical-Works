#!/bin/bash

DIR="/root/practice3/part2"
FIFO="$DIR/cuckoo.fifo"

# Проверка имени скрипта
NAME=$(basename "$0")

if [[ "$NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

# Журнал с именем запущенного скрипта
LOG="$PWD/report_${NAME}.log"

# PID текущего процесса
PID=$BASHPID

# Запись запуска
echo "$(date '+%F %T') [$PID] Скрипт запущен" >> "$LOG"

# Проверка основного канала
if [[ ! -p "$FIFO" ]]; then
    echo "Ошибка: канал cuckoo.sh не найден"
    exit 1
fi

# Создание канала для ответа
REPLY="$DIR/reply_${PID}.fifo"

mkfifo "$REPLY" || exit 1

cleanup() {
    rm -f "$REPLY"
}

trap cleanup EXIT

# Запрос времени ожидания
echo "${NAME}[${PID}]: how much time do I have?" > "$FIFO"

# Получение ответа
if ! N=$(timeout 5 cat "$REPLY"); then
    echo "Ошибка: ответ от cuckoo.sh не получен"
    exit 1
fi

# Проверка диапазона
if ! [[ "$N" =~ ^[0-9]+$ ]] || (( N < 2 || N > 10 )); then
    echo "Ошибка: некорректное время ожидания"
    exit 1
fi

# Ожидание
sleep "$N"

# Запись завершения
echo "$(date '+%F %T') [$PID] Скрипт завершился, работал $N секунд." >> "$LOG"
