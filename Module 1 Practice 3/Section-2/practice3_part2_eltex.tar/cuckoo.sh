#!/bin/bash

set -u

DIR="/root/practice3/part2"
LOG="$DIR/cuckoo.log"
PIPE=""

for arg in "$@"; do
    case "$arg" in
        --pishitesuda=*)
            PIPE="${arg#*=}"
            ;;
    esac
done

if [[ -z "$PIPE" || "$PIPE" != /* ]]; then
    echo "Укажите абсолютный путь к FIFO"
    exit 1
fi

if [[ -e "$PIPE" ]]; then
    echo "Канал уже существует: $PIPE"
    exit 1
fi

mkfifo "$PIPE" || exit 1

cleanup() {
    trap - TERM INT
    echo "$(date '+%F %T') Shutdown!" >> "$LOG"
    rm -f "$PIPE"
    exit 0
}

trap cleanup TERM INT

echo "$(date '+%F %T') Startup!" >> "$LOG"

while true; do
    if IFS= read -r request < "$PIPE"; then
        if [[ "$request" =~ ^(.+)\[([0-9]+)\]:[[:space:]]how[[:space:]]much[[:space:]]time[[:space:]]do[[:space:]]I[[:space:]]have\?$ ]]; then

            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            n=$((RANDOM % 9 + 2))

            echo "$(date '+%F %T') ${name}[${pid}] $n" >> "$LOG"

            reply="$DIR/reply_${pid}.fifo"

            if [[ -p "$reply" ]]; then
                timeout 3 bash -c 'printf "%s\n" "$1" > "$2"' _ "$n" "$reply" || true
            fi
        fi
    fi
done
